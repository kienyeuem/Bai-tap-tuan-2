"""
=============================================================================
BÀI TẬP TRÍ TUỆ NHÂN TẠO - HỆ THỐNG LOGIC MỜ GRABBIKE
=============================================================================
Hệ thống giá và điểm thưởng GrabBike sử dụng Fuzzy Logic
- 6 biến đầu vào, 2 biến đầu ra, 20 luật mờ
- Phương pháp: Mamdani Fuzzy Inference System
- Giải mờ: Phương pháp trọng tâm (Centroid Defuzzification)
=============================================================================
"""

import numpy as np

# =============================================================================
# PHẦN 1: ĐỊNH NGHĨA HÀM THUỘC (MEMBERSHIP FUNCTIONS)
# =============================================================================

def trimf(x, params):
    """Hàm thuộc tam giác (Triangular MF)"""
    a, b, c = params
    result = np.zeros_like(x, dtype=float)
    # Cạnh trái
    mask1 = (x > a) & (x <= b)
    if b - a != 0:
        result[mask1] = (x[mask1] - a) / (b - a)
    # Cạnh phải
    mask2 = (x > b) & (x < c)
    if c - b != 0:
        result[mask2] = (c - x[mask2]) / (c - b)
    # Đỉnh
    result[x == b] = 1.0
    return result

def trapmf(x, params):
    """Hàm thuộc hình thang (Trapezoidal MF)"""
    a, b, c, d = params
    result = np.zeros_like(x, dtype=float)
    # Cạnh trái lên
    mask1 = (x > a) & (x < b)
    if b - a != 0:
        result[mask1] = (x[mask1] - a) / (b - a)
    # Đỉnh phẳng
    mask2 = (x >= b) & (x <= c)
    result[mask2] = 1.0
    # Cạnh phải xuống
    mask3 = (x > c) & (x < d)
    if d - c != 0:
        result[mask3] = (d - x[mask3]) / (d - c)
    return result

# --- Biến đầu vào ---

# 1. Quãng đường / Ride Distance (km): 0 - 50
x_distance = np.linspace(0, 50, 500)

def distance_short(x):     return trapmf(x, [0, 0, 1, 5])
def distance_medium(x):    return trimf(x, [2, 5, 12])
def distance_long(x):      return trimf(x, [6, 13, 25])
def distance_very_long(x): return trapmf(x, [15, 25, 50, 50])

# 2. Lưu lượng giao thông / Traffic Condition (%): 0 - 100
x_traffic = np.linspace(0, 100, 500)

def traffic_low(x):    return trapmf(x, [0, 0, 10, 40])
def traffic_medium(x): return trimf(x, [20, 45, 70])
def traffic_high(x):   return trapmf(x, [60, 80, 100, 100])

# 3. Mức cầu / Demand Level (%): 0 - 100
x_demand = np.linspace(0, 100, 500)

def demand_low(x):    return trapmf(x, [0, 0, 10, 40])
def demand_medium(x): return trimf(x, [20, 45, 70])
def demand_high(x):   return trapmf(x, [60, 80, 100, 100])

# 4. Thời tiết / Weather: 0 (Tốt) -> 10 (Xấu)
x_weather = np.linspace(0, 10, 500)

def weather_good(x):     return trapmf(x, [0, 0, 1, 4])
def weather_moderate(x): return trimf(x, [2, 5, 8])
def weather_bad(x):      return trapmf(x, [6, 9, 10, 10])

# 5. Đánh giá khách hàng / Customer Rating: 1.0 - 5.0
x_rating = np.linspace(1, 5, 500)

def rating_poor(x):    return trapmf(x, [1.0, 1.0, 1.5, 2.8])
def rating_average(x): return trimf(x, [2.0, 3.0, 4.0])
def rating_good(x):    return trapmf(x, [3.5, 4.2, 5.0, 5.0])

# 6. Đúng giờ / Ride Punctuality (%): 0 - 100
x_punctuality = np.linspace(0, 100, 500)

def punctuality_late(x):    return trapmf(x, [0, 0, 20, 55])
def punctuality_ontime(x):  return trimf(x, [40, 60, 80])
def punctuality_early(x):   return trapmf(x, [70, 85, 100, 100])

# --- Biến đầu ra ---

# 1. Giá đi xe / Ride Price: 0 - 100 (đơn vị tương đối)
x_price = np.linspace(0, 100, 500)

def price_low(x):       return trapmf(x, [0, 0, 10, 30])
def price_medium(x):    return trimf(x, [20, 45, 70])
def price_high(x):      return trimf(x, [55, 75, 90])
def price_very_high(x): return trapmf(x, [80, 90, 100, 100])

# 2. Điểm thưởng / Reward Points: 0 - 100
x_reward = np.linspace(0, 100, 500)

def reward_none(x):     return trapmf(x, [0, 0, 5, 15])
def reward_few(x):      return trimf(x, [10, 25, 45])
def reward_moderate(x): return trimf(x, [35, 55, 75])
def reward_high(x):     return trapmf(x, [65, 80, 100, 100])


# =============================================================================
# PHẦN 2: ĐÁNH GIÁ ĐỘ THUỘC CỦA ĐẦU VÀO
# =============================================================================

def fuzzify(dist, traffic, demand, weather, rating, punctuality):
    """Tính độ thuộc (membership degree) cho tất cả các tập mờ."""
    d = np.array([dist])
    t = np.array([traffic])
    dm = np.array([demand])
    w = np.array([weather])
    r = np.array([rating])
    p = np.array([punctuality])

    return {
        'dist_short':     float(distance_short(d)),
        'dist_medium':    float(distance_medium(d)),
        'dist_long':      float(distance_long(d)),
        'dist_very_long': float(distance_very_long(d)),
        'traffic_low':    float(traffic_low(t)),
        'traffic_medium': float(traffic_medium(t)),
        'traffic_high':   float(traffic_high(t)),
        'demand_low':     float(demand_low(dm)),
        'demand_medium':  float(demand_medium(dm)),
        'demand_high':    float(demand_high(dm)),
        'weather_good':     float(weather_good(w)),
        'weather_moderate': float(weather_moderate(w)),
        'weather_bad':      float(weather_bad(w)),
        'rating_poor':    float(rating_poor(r)),
        'rating_average': float(rating_average(r)),
        'rating_good':    float(rating_good(r)),
        'punct_late':    float(punctuality_late(p)),
        'punct_ontime':  float(punctuality_ontime(p)),
        'punct_early':   float(punctuality_early(p)),
    }


# =============================================================================
# PHẦN 3: CƠ SỞ LUẬT MỜ (20 LUẬT)
# =============================================================================

def evaluate_rules(m):
    """
    Đánh giá 20 luật mờ theo phương pháp Mamdani.
    Toán tử VÀ (AND) = min, HOẶC (OR) = max
    Trả về danh sách (rule_strength, output_variable, output_set)
    """
    rules = []

    # ===================== LUẬT GIÁ (1-10) =====================

    # Luật 1: Nếu (Khoảng cách ngắn) VÀ (Lưu lượng thấp) VÀ (Nhu cầu thấp) → Giá thấp
    r1 = min(m['dist_short'], m['traffic_low'], m['demand_low'])
    rules.append((r1, 'price', 'low'))

    # Luật 2: Nếu (Khoảng cách ngắn) VÀ (Lưu lượng trung bình) VÀ (Nhu cầu cao) → Giá trung bình
    r2 = min(m['dist_short'], m['traffic_medium'], m['demand_high'])
    rules.append((r2, 'price', 'medium'))

    # Luật 3: Nếu (Khoảng cách xa) VÀ (Lưu lượng cao) VÀ (Nhu cầu cao) → Giá cao
    r3 = min(m['dist_long'], m['traffic_high'], m['demand_high'])
    rules.append((r3, 'price', 'high'))

    # Luật 4: Nếu (Khoảng cách xa) VÀ (Lưu lượng trung bình) VÀ (Thời tiết tốt) → Giá trung bình
    r4 = min(m['dist_long'], m['traffic_medium'], m['weather_good'])
    rules.append((r4, 'price', 'medium'))

    # Luật 5: Nếu (Khoảng cách xa) VÀ (Lưu lượng cao) VÀ (Thời tiết xấu) → Giá rất cao
    r5 = min(m['dist_long'], m['traffic_high'], m['weather_bad'])
    rules.append((r5, 'price', 'very_high'))

    # Luật 6: Nếu (Khoảng cách rất xa) VÀ (Lưu lượng cao) VÀ (Nhu cầu cao) → Giá rất cao
    r6 = min(m['dist_very_long'], m['traffic_high'], m['demand_high'])
    rules.append((r6, 'price', 'very_high'))

    # Luật 7: Nếu (Khoảng cách trung bình) VÀ (Lưu lượng thấp) VÀ (Nhu cầu thấp) → Giá trung bình
    r7 = min(m['dist_medium'], m['traffic_low'], m['demand_low'])
    rules.append((r7, 'price', 'medium'))

    # Luật 8: Nếu (Khoảng cách ngắn) VÀ (Lưu lượng cao) VÀ (Thời tiết xấu) → Giá cao
    r8 = min(m['dist_short'], m['traffic_high'], m['weather_bad'])
    rules.append((r8, 'price', 'high'))

    # Luật 9: Nếu (Khoảng cách rất xa) VÀ (Thời tiết xấu) → Giá rất cao
    r9 = min(m['dist_very_long'], m['weather_bad'])
    rules.append((r9, 'price', 'very_high'))

    # Luật 10: Nếu (Khoảng cách trung bình) VÀ (Lưu lượng trung bình) VÀ (Thời tiết tốt) → Giá trung bình
    r10 = min(m['dist_medium'], m['traffic_medium'], m['weather_good'])
    rules.append((r10, 'price', 'medium'))

    # ===================== LUẬT ĐIỂM THƯỞNG (11-20) =====================

    # Luật 11: Nếu (Đánh giá khách hàng tốt) VÀ (Đúng giờ sớm) → Điểm thưởng cao
    r11 = min(m['rating_good'], m['punct_early'])
    rules.append((r11, 'reward', 'high'))

    # Luật 12: Nếu (Đánh giá trung bình) VÀ (Đúng giờ) → Điểm thưởng trung bình
    r12 = min(m['rating_average'], m['punct_ontime'])
    rules.append((r12, 'reward', 'moderate'))

    # Luật 13: Nếu (Đánh giá kém) VÀ (Đúng giờ muộn) → Điểm thưởng không có
    r13 = min(m['rating_poor'], m['punct_late'])
    rules.append((r13, 'reward', 'none'))

    # Luật 14: Nếu (Khoảng cách dài) VÀ (Lưu lượng cao) VÀ (Đúng giờ) → Điểm thưởng cao
    r14 = min(m['dist_long'], m['traffic_high'], m['punct_ontime'])
    rules.append((r14, 'reward', 'high'))

    # Luật 15: Nếu (Khoảng cách trung bình) VÀ (Giao thông trung bình) VÀ (Đánh giá tốt) → Điểm thưởng trung bình
    r15 = min(m['dist_medium'], m['traffic_medium'], m['rating_good'])
    rules.append((r15, 'reward', 'moderate'))

    # Luật 16: Nếu (Đánh giá kém) VÀ (Đúng giờ trễ) → Điểm thưởng không có
    r16 = min(m['rating_poor'], m['punct_late'])
    rules.append((r16, 'reward', 'none'))

    # Luật 17: Nếu (Khoảng cách rất xa) VÀ (Thời tiết xấu) VÀ (Đánh giá tốt) → Điểm thưởng cao
    r17 = min(m['dist_very_long'], m['weather_bad'], m['rating_good'])
    rules.append((r17, 'reward', 'high'))

    # Luật 18: Nếu (Khoảng cách ngắn) VÀ (Đánh giá trung bình) VÀ (Đúng giờ) → Điểm thưởng ít
    r18 = min(m['dist_short'], m['rating_average'], m['punct_ontime'])
    rules.append((r18, 'reward', 'few'))

    # Luật 19: Nếu (Khoảng cách dài) VÀ (Giao thông cao) VÀ (Đúng giờ trễ) → Điểm thưởng ít
    r19 = min(m['dist_long'], m['traffic_high'], m['punct_late'])
    rules.append((r19, 'reward', 'few'))

    # Luật 20: Nếu (Khoảng cách trung bình) VÀ (Thời tiết trung bình) VÀ (Đánh giá tốt) → Điểm thưởng trung bình
    r20 = min(m['dist_medium'], m['weather_moderate'], m['rating_good'])
    rules.append((r20, 'reward', 'moderate'))

    return rules


# =============================================================================
# PHẦN 4: SUY LUẬN MỜ VÀ GIẢI MỜ (DEFUZZIFICATION)
# =============================================================================

def aggregate_and_defuzzify(rules):
    """
    Tổng hợp kết quả các luật và giải mờ bằng phương pháp trọng tâm (Centroid).
    """
    # Tập hợp các hàm thuộc đầu ra
    price_mfs = {
        'low': price_low,
        'medium': price_medium,
        'high': price_high,
        'very_high': price_very_high,
    }
    reward_mfs = {
        'none': reward_none,
        'few': reward_few,
        'moderate': reward_moderate,
        'high': reward_high,
    }

    # Tổng hợp (aggregation) bằng phương pháp max
    price_agg = np.zeros_like(x_price)
    reward_agg = np.zeros_like(x_reward)

    for strength, output_var, output_set in rules:
        if strength == 0:
            continue
        if output_var == 'price':
            mf_values = price_mfs[output_set](x_price)
            clipped = np.minimum(mf_values, strength)  # Cắt (clip) theo độ kích hoạt
            price_agg = np.maximum(price_agg, clipped)  # Hợp (max)
        elif output_var == 'reward':
            mf_values = reward_mfs[output_set](x_reward)
            clipped = np.minimum(mf_values, strength)
            reward_agg = np.maximum(reward_agg, clipped)

    # Giải mờ bằng phương pháp trọng tâm (Centroid)
    if np.sum(price_agg) > 0:
        price_result = np.sum(x_price * price_agg) / np.sum(price_agg)
    else:
        price_result = 0

    if np.sum(reward_agg) > 0:
        reward_result = np.sum(x_reward * reward_agg) / np.sum(reward_agg)
    else:
        reward_result = 0

    return price_result, reward_result, price_agg, reward_agg


# =============================================================================
# PHẦN 5: HÀM CHÍNH - CHẠY HỆ THỐNG
# =============================================================================

def grabbike_fuzzy_system(dist, traffic, demand, weather, rating, punctuality):
    """
    Hệ thống suy luận mờ GrabBike hoàn chỉnh.

    Tham số:
        dist:        Quãng đường (km), 0-50
        traffic:     Lưu lượng giao thông (%), 0-100
        demand:      Mức cầu (%), 0-100
        weather:     Thời tiết, 0 (Tốt) - 10 (Xấu)
        rating:      Đánh giá khách hàng, 1.0-5.0
        punctuality: Đúng giờ (%), 0-100

    Trả về:
        price:  Giá đi xe (0-100)
        reward: Điểm thưởng (0-100)
    """
    # Bước 1: Mờ hóa (Fuzzification)
    memberships = fuzzify(dist, traffic, demand, weather, rating, punctuality)

    # Bước 2: Đánh giá luật (Rule Evaluation)
    rules = evaluate_rules(memberships)

    # Bước 3: Tổng hợp và Giải mờ (Aggregation & Defuzzification)
    price, reward, price_agg, reward_agg = aggregate_and_defuzzify(rules)

    return price, reward, memberships, rules, price_agg, reward_agg


# =============================================================================
# PHẦN 6: CHẠY VÍ DỤ MINH HỌA
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  HỆ THỐNG LOGIC MỜ GRABBIKE - TRÍ TUỆ NHÂN TẠO")
    print("  Giá đi xe & Điểm thưởng khách hàng")
    print("=" * 70)

    # Các tình huống kiểm thử
    test_cases = [
        {
            'name': 'Tình huống 1: Quãng đường ngắn, giao thông thấp, cầu thấp',
            'inputs': (2, 15, 10, 2, 4.0, 80),
        },
        {
            'name': 'Tình huống 2: Quãng đường dài, giao thông cao, thời tiết xấu',
            'inputs': (15, 85, 75, 9, 3.0, 50),
        },
        {
            'name': 'Tình huống 3: Quãng đường trung bình, mọi thứ trung bình',
            'inputs': (7, 50, 45, 5, 3.0, 60),
        },
        {
            'name': 'Tình huống 4: Rất xa, cầu cao, khách hàng tốt',
            'inputs': (30, 90, 85, 8, 4.5, 90),
        },
        {
            'name': 'Tình huống 5: Ngắn, giao thông cao, thời tiết xấu, đánh giá kém',
            'inputs': (2, 85, 60, 9, 1.5, 20),
        },
    ]

    for tc in test_cases:
        dist, traffic, demand, weather, rating, punctuality = tc['inputs']
        price, reward, memberships, rules, _, _ = grabbike_fuzzy_system(
            dist, traffic, demand, weather, rating, punctuality
        )

        print(f"\n{'─' * 70}")
        print(f"  {tc['name']}")
        print(f"{'─' * 70}")
        print(f"  ĐẦU VÀO:")
        print(f"    Quãng đường:    {dist} km")
        print(f"    Giao thông:     {traffic}%")
        print(f"    Mức cầu:        {demand}%")
        print(f"    Thời tiết:      {weather}/10 (0=Tốt, 10=Xấu)")
        print(f"    Đánh giá KH:    {rating}/5.0")
        print(f"    Đúng giờ:       {punctuality}%")

        print(f"\n  ĐỘ THUỘC (Fuzzification):")
        print(f"    Khoảng cách:  Ngắn={memberships['dist_short']:.3f}, "
              f"TB={memberships['dist_medium']:.3f}, "
              f"Dài={memberships['dist_long']:.3f}, "
              f"Rất xa={memberships['dist_very_long']:.3f}")
        print(f"    Giao thông:   Thấp={memberships['traffic_low']:.3f}, "
              f"TB={memberships['traffic_medium']:.3f}, "
              f"Cao={memberships['traffic_high']:.3f}")
        print(f"    Mức cầu:      Thấp={memberships['demand_low']:.3f}, "
              f"TB={memberships['demand_medium']:.3f}, "
              f"Cao={memberships['demand_high']:.3f}")
        print(f"    Thời tiết:    Tốt={memberships['weather_good']:.3f}, "
              f"TB={memberships['weather_moderate']:.3f}, "
              f"Xấu={memberships['weather_bad']:.3f}")
        print(f"    Đánh giá KH:  Kém={memberships['rating_poor']:.3f}, "
              f"TB={memberships['rating_average']:.3f}, "
              f"Tốt={memberships['rating_good']:.3f}")
        print(f"    Đúng giờ:     Trễ={memberships['punct_late']:.3f}, "
              f"On-time={memberships['punct_ontime']:.3f}, "
              f"Sớm={memberships['punct_early']:.3f}")

        print(f"\n  LUẬT ĐƯỢC KÍCH HOẠT:")
        rule_names = [
            "L1:  Ngắn ∧ LLThấp ∧ CầuThấp → Giá Thấp",
            "L2:  Ngắn ∧ LLTB ∧ CầuCao → Giá TB",
            "L3:  Dài ∧ LLCao ∧ CầuCao → Giá Cao",
            "L4:  Dài ∧ LLTB ∧ TTTốt → Giá TB",
            "L5:  Dài ∧ LLCao ∧ TTXấu → Giá Rất cao",
            "L6:  Rất xa ∧ LLCao ∧ CầuCao → Giá Rất cao",
            "L7:  TB ∧ LLThấp ∧ CầuThấp → Giá TB",
            "L8:  Ngắn ∧ LLCao ∧ TTXấu → Giá Cao",
            "L9:  Rất xa ∧ TTXấu → Giá Rất cao",
            "L10: TB ∧ LLTB ∧ TTTốt → Giá TB",
            "L11: ĐGTốt ∧ Sớm → Thưởng Cao",
            "L12: ĐGTB ∧ Đúng giờ → Thưởng TB",
            "L13: ĐGKém ∧ Trễ → Thưởng Không có",
            "L14: Dài ∧ LLCao ∧ Đúng giờ → Thưởng Cao",
            "L15: TB ∧ GTTB ∧ ĐGTốt → Thưởng TB",
            "L16: ĐGKém ∧ Trễ → Thưởng Không có",
            "L17: Rất xa ∧ TTXấu ∧ ĐGTốt → Thưởng Cao",
            "L18: Ngắn ∧ ĐGTB ∧ Đúng giờ → Thưởng Ít",
            "L19: Dài ∧ LLCao ∧ Trễ → Thưởng Ít",
            "L20: TB ∧ TTTB ∧ ĐGTốt → Thưởng TB",
        ]
        for i, (strength, _, _) in enumerate(rules):
            if strength > 0:
                print(f"    {rule_names[i]}  =>  Độ kích hoạt = {strength:.3f}")

        print(f"\n  ★ KẾT QUẢ GIẢI MỜ (Centroid):")
        print(f"    → Giá đi xe:      {price:.2f} / 100")
        print(f"    → Điểm thưởng:    {reward:.2f} / 100")

        # Phân loại ngôn ngữ
        if price < 25:
            price_label = "THẤP"
        elif price < 55:
            price_label = "TRUNG BÌNH"
        elif price < 80:
            price_label = "CAO"
        else:
            price_label = "RẤT CAO"

        if reward < 12:
            reward_label = "KHÔNG CÓ"
        elif reward < 35:
            reward_label = "ÍT"
        elif reward < 65:
            reward_label = "TRUNG BÌNH"
        else:
            reward_label = "CAO"

        print(f"    → Giá (ngôn ngữ):     {price_label}")
        print(f"    → Thưởng (ngôn ngữ):  {reward_label}")

    print(f"\n{'=' * 70}")
    print("  HOÀN TẤT - Đang vẽ đồ thị...")
    print(f"{'=' * 70}")

    # =================================================================
    # PHẦN 7: VẼ ĐỒ THỊ HÀM LIÊN THUỘC + KẾT QUẢ SUY LUẬN
    # =================================================================
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.rcParams['font.size'] = 10

    colors = ['#2196F3', '#4CAF50', '#FF9800', '#F44336']

    # ─────────────────────────────────────────────────────────
    # FIGURE 1: ĐỒ THỊ HÀM LIÊN THUỘC CỦA TẤT CẢ BIẾN
    # ─────────────────────────────────────────────────────────
    fig1, axes = plt.subplots(4, 2, figsize=(15, 18))
    fig1.suptitle('ĐỒ THỊ HÀM LIÊN THUỘC - HỆ THỐNG LOGIC MỜ GRABBIKE',
                  fontsize=15, fontweight='bold', y=0.98)

    # 1. Quãng đường
    ax = axes[0, 0]
    x = np.linspace(0, 50, 500)
    ax.plot(x, distance_short(x),     color=colors[0], lw=2, label='Ngắn/Short')
    ax.plot(x, distance_medium(x),    color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, distance_long(x),      color=colors[2], lw=2, label='Dài/Long')
    ax.plot(x, distance_very_long(x), color=colors[3], lw=2, label='Rất xa/Very Long')
    ax.set_title('1. Quãng đường / Ride Distance (km)', fontweight='bold')
    ax.set_xlabel('km'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 2. Lưu lượng giao thông
    ax = axes[0, 1]
    x = np.linspace(0, 100, 500)
    ax.plot(x, traffic_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, traffic_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, traffic_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('2. Lưu lượng giao thông / Traffic (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 3. Mức cầu
    ax = axes[1, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, demand_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, demand_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, demand_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('3. Mức cầu / Demand Level (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 4. Thời tiết
    ax = axes[1, 1]
    x = np.linspace(0, 10, 500)
    ax.plot(x, weather_good(x),     color=colors[0], lw=2, label='Tốt/Good')
    ax.plot(x, weather_moderate(x), color=colors[1], lw=2, label='TB/Moderate')
    ax.plot(x, weather_bad(x),      color=colors[2], lw=2, label='Xấu/Bad')
    ax.set_title('4. Thời tiết / Weather', fontweight='bold')
    ax.set_xlabel('0=Tốt → 10=Xấu'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 5. Đánh giá khách hàng
    ax = axes[2, 0]
    x = np.linspace(1, 5, 500)
    ax.plot(x, rating_poor(x),    color=colors[0], lw=2, label='Kém/Poor')
    ax.plot(x, rating_average(x), color=colors[1], lw=2, label='TB/Average')
    ax.plot(x, rating_good(x),    color=colors[2], lw=2, label='Tốt/Good')
    ax.set_title('5. Đánh giá khách hàng / Customer Rating', fontweight='bold')
    ax.set_xlabel('Điểm (1.0-5.0)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 6. Đúng giờ
    ax = axes[2, 1]
    x = np.linspace(0, 100, 500)
    ax.plot(x, punctuality_late(x),   color=colors[0], lw=2, label='Trễ/Late')
    ax.plot(x, punctuality_ontime(x), color=colors[1], lw=2, label='Đúng giờ/On Time')
    ax.plot(x, punctuality_early(x),  color=colors[2], lw=2, label='Sớm/Early')
    ax.set_title('6. Đúng giờ / Ride Punctuality (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 7. Giá đi xe (ĐẦU RA)
    ax = axes[3, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, price_low(x),       color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, price_medium(x),    color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, price_high(x),      color=colors[2], lw=2, label='Cao/High')
    ax.plot(x, price_very_high(x), color=colors[3], lw=2, label='Rất cao/Very High')
    ax.set_title('7. [ĐẦU RA] Giá đi xe / Ride Price', fontweight='bold', color='red')
    ax.set_xlabel('Giá (tương đối)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 8. Điểm thưởng (ĐẦU RA)
    ax = axes[3, 1]
    x = np.linspace(0, 100, 500)
    ax.plot(x, reward_none(x),     color=colors[0], lw=2, label='Không có/None')
    ax.plot(x, reward_few(x),      color=colors[1], lw=2, label='Ít/Few')
    ax.plot(x, reward_moderate(x), color=colors[2], lw=2, label='TB/Moderate')
    ax.plot(x, reward_high(x),     color=colors[3], lw=2, label='Cao/High')
    ax.set_title('8. [ĐẦU RA] Điểm thưởng / Reward Points', fontweight='bold', color='red')
    ax.set_xlabel('Điểm thưởng (tương đối)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    # ─────────────────────────────────────────────────────────
    # FIGURE 2: KẾT QUẢ SUY LUẬN MỜ CHO TỪNG TÌNH HUỐNG
    # ─────────────────────────────────────────────────────────
    n_cases = len(test_cases)
    fig2, axes2 = plt.subplots(n_cases, 2, figsize=(14, 4 * n_cases))
    fig2.suptitle('KẾT QUẢ SUY LUẬN MỜ & GIẢI MỜ TRỌNG TÂM (CENTROID)',
                  fontsize=14, fontweight='bold', y=0.99)

    for idx, tc in enumerate(test_cases):
        dist_val, traffic_val, demand_val, weather_val, rating_val, punct_val = tc['inputs']
        p, r, m, rules_out, p_agg, r_agg = grabbike_fuzzy_system(
            dist_val, traffic_val, demand_val, weather_val, rating_val, punct_val
        )

        # Cột trái: Giá
        ax_p = axes2[idx, 0]
        ax_p.fill_between(x_price, p_agg, alpha=0.45, color='#FF5722')
        ax_p.plot(x_price, p_agg, color='#D84315', lw=1.5)
        ax_p.axvline(x=p, color='red', lw=2, ls='--', label=f'Centroid = {p:.2f}')
        ax_p.set_title(f'TH{idx+1} - Giá: {p:.2f}', fontweight='bold', fontsize=10)
        ax_p.set_xlabel('Giá'); ax_p.set_ylabel('μ(x)')
        ax_p.legend(fontsize=8); ax_p.grid(True, alpha=0.3)
        ax_p.set_xlim(0, 100)

        # Cột phải: Thưởng
        ax_r = axes2[idx, 1]
        ax_r.fill_between(x_reward, r_agg, alpha=0.45, color='#4CAF50')
        ax_r.plot(x_reward, r_agg, color='#2E7D32', lw=1.5)
        ax_r.axvline(x=r, color='green', lw=2, ls='--', label=f'Centroid = {r:.2f}')
        ax_r.set_title(f'TH{idx+1} - Thưởng: {r:.2f}', fontweight='bold', fontsize=10)
        ax_r.set_xlabel('Điểm thưởng'); ax_r.set_ylabel('μ(x)')
        ax_r.legend(fontsize=8); ax_r.grid(True, alpha=0.3)
        ax_r.set_xlim(0, 100)

        # Ghi chú input bên trái
        info = f'd={dist_val}km, GT={traffic_val}%, C={demand_val}%, TT={weather_val}, ĐG={rating_val}, P={punct_val}%'
        ax_p.text(0.02, 0.95, info, transform=ax_p.transAxes, fontsize=7,
                  va='top', ha='left', bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.7))

    plt.tight_layout(rect=[0, 0, 1, 0.97])

    print("\n  → Đồ thị đang hiển thị. Đóng cửa sổ đồ thị để kết thúc.")
    plt.show()
