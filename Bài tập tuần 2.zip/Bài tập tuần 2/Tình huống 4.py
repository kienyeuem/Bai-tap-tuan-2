"""
=============================================================================
BAI TAP TRI TUE NHAN TAO - HE THONG LOGIC MO
TINH HUONG 4: TOI UU HOA THOI GIAN GIAO HANG VA TANG THU NHAP CHO TAI XE
=============================================================================
5 bien dau vao, 2 bien dau ra, 8 luat mo
Phuong phap: Mamdani Fuzzy Inference System
Giai mo: Phuong phap trong tam (Centroid Defuzzification)
=============================================================================

BIEN DAU VAO:
  1. Mat do don hang / Order Density (Thap, TB, Cao)
  2. Giao hang khan cap / Delivery Urgency (Thap, TB, Cao)
  3. Tai trong tai xe / Driver's Current Load (Thap, TB, Cao)
  4. Tinh trang giao thong / Traffic Conditions (Thap, TB, Cao)
  5. Loi nhuan moi lan giao / Profit Per Delivery (Thap, TB, Cao)

BIEN DAU RA:
  1. So luong don hang ket hop / Number of Orders to Combine (It, Mot so, Nhieu)
  2. Uu tien giao hang / Delivery Priority (Thap, TB, Cao)

LUAT KET HOP DON HANG (1-5):
  1. MatDo_Cao ^ TaiTrong_Thap ^ GT_Thap -> Ket hop NHIEU
  2. MatDo_TB ^ GT_Cao ^ KhanCap_TB -> Ket hop MOT VAI
  3. TaiTrong_Cao ^ MatDo_Cao ^ LN_TB -> Ket hop MOT SO (tranh qua tai)
  4. MatDo_Thap ^ KhanCap_Cao ^ GT_TB -> Ket hop MOT VAI
  5. LN_Cao ^ KhanCap_Cao ^ GT_Cao -> Ket hop MOT VAI (dam bao gia tri cao)

LUAT UU TIEN GIAO HANG (6-8):
  6. KhanCap_Cao ^ LN_Cao -> Uu tien CAO
  7. KhanCap_TB ^ GT_TB -> Uu tien TB
  8. KhanCap_Thap ^ MatDo_Cao ^ LN_Thap -> Uu tien THAP (giao sau)
=============================================================================
"""

import numpy as np

# =============================================================================
# PHAN 1: HAM THUOC (MEMBERSHIP FUNCTIONS)
# =============================================================================

def trimf(x, params):
    a, b, c = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x <= b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x > b) & (x < c)
    if c - b != 0: result[mask2] = (c - x[mask2]) / (c - b)
    result[x == b] = 1.0
    return result

def trapmf(x, params):
    a, b, c, d = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x < b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x >= b) & (x <= c)
    result[mask2] = 1.0
    mask3 = (x > c) & (x < d)
    if d - c != 0: result[mask3] = (d - x[mask3]) / (d - c)
    return result

# --- 1. Mat do don hang / Order Density: 0 - 100 ---
x_density = np.linspace(0, 100, 500)
def density_low(x):    return trapmf(x, [0, 0, 10, 40])
def density_medium(x): return trimf(x, [25, 50, 75])
def density_high(x):   return trapmf(x, [60, 80, 100, 100])

# --- 2. Giao hang khan cap / Delivery Urgency: 0 - 10 ---
x_urgency = np.linspace(0, 10, 500)
def urgency_low(x):    return trapmf(x, [0, 0, 1, 4])
def urgency_medium(x): return trimf(x, [3, 5, 7])
def urgency_high(x):   return trapmf(x, [6, 8, 10, 10])

# --- 3. Tai trong tai xe / Driver Load: 0 - 100% ---
x_load = np.linspace(0, 100, 500)
def load_low(x):    return trapmf(x, [0, 0, 10, 35])
def load_medium(x): return trimf(x, [25, 50, 75])
def load_high(x):   return trapmf(x, [65, 85, 100, 100])

# --- 4. Giao thong / Traffic: 0 - 100 (0=thoang, 100=tac nghen) ---
x_traffic = np.linspace(0, 100, 500)
def traffic_low(x):    return trapmf(x, [0, 0, 15, 40])
def traffic_medium(x): return trimf(x, [25, 50, 75])
def traffic_high(x):   return trapmf(x, [60, 80, 100, 100])

# --- 5. Loi nhuan moi lan giao / Profit Per Delivery: 0 - 100 ---
x_profit = np.linspace(0, 100, 500)
def profit_low(x):    return trapmf(x, [0, 0, 15, 40])
def profit_medium(x): return trimf(x, [25, 50, 75])
def profit_high(x):   return trapmf(x, [60, 80, 100, 100])

# --- DAU RA 1: So luong don ket hop / Orders to Combine: 1 - 10 ---
x_combine = np.linspace(1, 10, 500)
def combine_few(x):  return trapmf(x, [1, 1, 2, 4])
def combine_some(x): return trimf(x, [3, 5, 7])
def combine_many(x): return trapmf(x, [6, 8, 10, 10])

# --- DAU RA 2: Uu tien giao hang / Delivery Priority: 0 - 100 ---
x_priority = np.linspace(0, 100, 500)
def priority_low(x):    return trapmf(x, [0, 0, 10, 35])
def priority_medium(x): return trimf(x, [25, 50, 75])
def priority_high(x):   return trapmf(x, [65, 85, 100, 100])


# =============================================================================
# PHAN 2: MO HOA
# =============================================================================

def fuzzify(density, urgency, load, traffic, profit):
    d = np.array([density])
    u = np.array([urgency])
    l = np.array([load])
    t = np.array([traffic])
    p = np.array([profit])
    return {
        'density_low':    float(density_low(d)[0]),
        'density_medium': float(density_medium(d)[0]),
        'density_high':   float(density_high(d)[0]),
        'urgency_low':    float(urgency_low(u)[0]),
        'urgency_medium': float(urgency_medium(u)[0]),
        'urgency_high':   float(urgency_high(u)[0]),
        'load_low':    float(load_low(l)[0]),
        'load_medium': float(load_medium(l)[0]),
        'load_high':   float(load_high(l)[0]),
        'traffic_low':    float(traffic_low(t)[0]),
        'traffic_medium': float(traffic_medium(t)[0]),
        'traffic_high':   float(traffic_high(t)[0]),
        'profit_low':    float(profit_low(p)[0]),
        'profit_medium': float(profit_medium(p)[0]),
        'profit_high':   float(profit_high(p)[0]),
    }


# =============================================================================
# PHAN 3: 8 LUAT MO
# =============================================================================

def evaluate_rules(m):
    rules = []

    # === LUAT KET HOP DON HANG (1-5) ===

    # L1: MatDo_Cao ^ TaiTrong_Thap ^ GT_Thap -> Ket hop NHIEU (toi da hoa)
    r1 = min(m['density_high'], m['load_low'], m['traffic_low'])
    rules.append((r1, 'combine', 'many'))

    # L2: MatDo_TB ^ GT_Cao ^ KhanCap_TB -> Ket hop MOT VAI (tranh cham tre)
    r2 = min(m['density_medium'], m['traffic_high'], m['urgency_medium'])
    rules.append((r2, 'combine', 'some'))

    # L3: TaiTrong_Cao ^ MatDo_Cao ^ LN_TB -> Ket hop MOT SO (tranh qua tai)
    r3 = min(m['load_high'], m['density_high'], m['profit_medium'])
    rules.append((r3, 'combine', 'some'))

    # L4: MatDo_Thap ^ KhanCap_Cao ^ GT_TB -> Ket hop MOT VAI (uu tien toc do)
    r4 = min(m['density_low'], m['urgency_high'], m['traffic_medium'])
    rules.append((r4, 'combine', 'few'))

    # L5: LN_Cao ^ KhanCap_Cao ^ GT_Cao -> Ket hop MOT VAI (dam bao gia tri)
    r5 = min(m['profit_high'], m['urgency_high'], m['traffic_high'])
    rules.append((r5, 'combine', 'some'))

    # === LUAT UU TIEN GIAO HANG (6-8) ===

    # L6: KhanCap_Cao ^ LN_Cao -> Uu tien CAO (giao hang truoc)
    r6 = min(m['urgency_high'], m['profit_high'])
    rules.append((r6, 'priority', 'high'))

    # L7: KhanCap_TB ^ GT_TB -> Uu tien TB
    r7 = min(m['urgency_medium'], m['traffic_medium'])
    rules.append((r7, 'priority', 'medium'))

    # L8: KhanCap_Thap ^ MatDo_Cao ^ LN_Thap -> Uu tien THAP (giao sau)
    r8 = min(m['urgency_low'], m['density_high'], m['profit_low'])
    rules.append((r8, 'priority', 'low'))

    return rules


# =============================================================================
# PHAN 4: TONG HOP VA GIAI MO
# =============================================================================

def aggregate_and_defuzzify(rules):
    combine_mfs = {
        'few':  combine_few,
        'some': combine_some,
        'many': combine_many,
    }
    priority_mfs = {
        'low':    priority_low,
        'medium': priority_medium,
        'high':   priority_high,
    }

    comb_agg = np.zeros_like(x_combine)
    prio_agg = np.zeros_like(x_priority)

    for strength, out_var, out_set in rules:
        if strength == 0:
            continue
        if out_var == 'combine':
            mf = combine_mfs[out_set](x_combine)
            clipped = np.minimum(mf, strength)
            comb_agg = np.maximum(comb_agg, clipped)
        elif out_var == 'priority':
            mf = priority_mfs[out_set](x_priority)
            clipped = np.minimum(mf, strength)
            prio_agg = np.maximum(prio_agg, clipped)

    if np.sum(comb_agg) > 0:
        comb_result = np.sum(x_combine * comb_agg) / np.sum(comb_agg)
    else:
        comb_result = 0

    if np.sum(prio_agg) > 0:
        prio_result = np.sum(x_priority * prio_agg) / np.sum(prio_agg)
    else:
        prio_result = 0

    return comb_result, prio_result, comb_agg, prio_agg


def giaohang_fuzzy(density, urgency, load, traffic, profit):
    memberships = fuzzify(density, urgency, load, traffic, profit)
    rules = evaluate_rules(memberships)
    combine, priority, comb_agg, prio_agg = aggregate_and_defuzzify(rules)
    return combine, priority, memberships, rules, comb_agg, prio_agg


# =============================================================================
# PHAN 5: CHAY
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  HE THONG LOGIC MO - TOI UU GIAO HANG & THU NHAP TAI XE")
    print("=" * 70)

    rule_names = [
        "L1: MatDo_Cao ^ TT_Thap ^ GT_Thap        -> Ket hop NHIEU",
        "L2: MatDo_TB ^ GT_Cao ^ KC_TB              -> Ket hop MOT VAI",
        "L3: TaiTrong_Cao ^ MatDo_Cao ^ LN_TB      -> Ket hop MOT SO",
        "L4: MatDo_Thap ^ KC_Cao ^ GT_TB            -> Ket hop IT",
        "L5: LN_Cao ^ KC_Cao ^ GT_Cao               -> Ket hop MOT VAI",
        "L6: KC_Cao ^ LN_Cao                         -> Uu tien CAO",
        "L7: KC_TB ^ GT_TB                            -> Uu tien TB",
        "L8: KC_Thap ^ MatDo_Cao ^ LN_Thap          -> Uu tien THAP",
    ]

    # Tinh huong giao trinh:
    # Mat do don hang: Cao
    # Muc do khan cap: Trung binh
    # Tai trong tai xe: Thap
    # Dieu kien giao thong: Trung binh (toc do 30 km/h)
    # Loi nhuan moi lan giao: Trung binh
    test_cases = [
        {
            'name': 'TINH HUONG GIAO TRINH: MatDo Cao, KC TB, TaiTrong Thap, GT TB, LN TB',
            'inputs': (80, 5, 15, 50, 50),
            'note': 'Nen ket hop nhieu don vi mat do cao + tai trong thap. Uu tien TB.',
        },
    ]

    results = []

    for tc in test_cases:
        density, urgency, load, traffic, profit = tc['inputs']
        combine, priority, memberships, rules, comb_agg, prio_agg = giaohang_fuzzy(
            density, urgency, load, traffic, profit
        )
        results.append((tc, combine, priority, memberships, rules, comb_agg, prio_agg))

        print(f"\n{'---' * 23}")
        print(f"  {tc['name']}")
        if tc['note']:
            print(f"  ({tc['note']})")
        print(f"{'---' * 23}")
        print(f"  DAU VAO:")
        print(f"    Mat do don hang:        {density}%")
        print(f"    Muc do khan cap:        {urgency} / 10")
        print(f"    Tai trong tai xe:       {load}%")
        print(f"    Giao thong:             {traffic}% (0=thoang, 100=tac)")
        print(f"    Loi nhuan/lan giao:     {profit}%")

        print(f"\n  DO THUOC (Fuzzification):")
        print(f"    Mat do:     Thap={memberships['density_low']:.3f}, "
              f"TB={memberships['density_medium']:.3f}, "
              f"Cao={memberships['density_high']:.3f}")
        print(f"    Khan cap:   Thap={memberships['urgency_low']:.3f}, "
              f"TB={memberships['urgency_medium']:.3f}, "
              f"Cao={memberships['urgency_high']:.3f}")
        print(f"    Tai trong:  Thap={memberships['load_low']:.3f}, "
              f"TB={memberships['load_medium']:.3f}, "
              f"Cao={memberships['load_high']:.3f}")
        print(f"    Giao thong: Thap={memberships['traffic_low']:.3f}, "
              f"TB={memberships['traffic_medium']:.3f}, "
              f"Cao={memberships['traffic_high']:.3f}")
        print(f"    Loi nhuan:  Thap={memberships['profit_low']:.3f}, "
              f"TB={memberships['profit_medium']:.3f}, "
              f"Cao={memberships['profit_high']:.3f}")

        print(f"\n  LUAT DUOC KICH HOAT:")
        activated = False
        for i, (strength, _, _) in enumerate(rules):
            if strength > 0:
                print(f"    {rule_names[i]}  =>  alpha = {strength:.3f}")
                activated = True
        if not activated:
            print(f"    (Khong co luat nao duoc kich hoat)")

        # Phan loai ket hop
        if combine < 3:
            comb_label = "IT (1-3 don)"
        elif combine < 6.5:
            comb_label = "MOT SO (3-7 don)"
        else:
            comb_label = "NHIEU (7-10 don)"

        # Phan loai uu tien
        if priority < 30:
            prio_label = "THAP (giao sau)"
        elif priority < 65:
            prio_label = "TRUNG BINH"
        else:
            prio_label = "CAO (giao truoc)"

        print(f"\n  * KET QUA GIAI MO (Centroid):")
        print(f"    -> So don ket hop:      {combine:.2f} / 10")
        print(f"    -> Phan loai:           {comb_label}")
        print(f"    -> Muc uu tien:         {priority:.2f} / 100")
        print(f"    -> Phan loai:           {prio_label}")

        # Ket luan
        print(f"\n  KET LUAN:")
        print(f"    He thong chi dinh {combine:.0f} lan giao hang cho tai xe,")
        print(f"    toi uu hoa ca thoi gian va thu nhap.")
        if combine >= 5:
            print(f"    => Nen ket hop nhieu don hang vi mat do cao va tai xe thap.")
        else:
            print(f"    => Ket hop vua phai de dam bao toc do giao hang.")
        if priority >= 50:
            print(f"    => Muc do uu tien giao hang o muc trung binh - cao.")
        else:
            print(f"    => Muc do uu tien trung binh, khan cap vua phai.")

    print(f"\n{'=' * 70}")
    print("  HOAN TAT - Dang ve do thi...")
    print(f"{'=' * 70}")

    # =================================================================
    # PHAN 6: VE DO THI
    # =================================================================
    import matplotlib.pyplot as plt

    colors = ['#2196F3', '#4CAF50', '#FF9800', '#F44336']

    # -- FIGURE 1: HAM LIEN THUOC --
    fig1, axes = plt.subplots(4, 2, figsize=(14, 16))
    fig1.suptitle('DO THI HAM LIEN THUOC - TOI UU GIAO HANG & THU NHAP TAI XE',
                  fontsize=14, fontweight='bold', y=0.98)

    # 1. Mat do don hang
    ax = axes[0, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, density_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, density_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, density_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('1. Mat do don hang / Order Density', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 2. Khan cap
    ax = axes[0, 1]
    x2 = np.linspace(0, 10, 500)
    ax.plot(x2, urgency_low(x2),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x2, urgency_medium(x2), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x2, urgency_high(x2),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('2. Muc do khan cap / Delivery Urgency', fontweight='bold')
    ax.set_xlabel('Muc (0-10)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 3. Tai trong
    ax = axes[1, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, load_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, load_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, load_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('3. Tai trong tai xe / Driver Load (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 4. Giao thong
    ax = axes[1, 1]
    ax.plot(x, traffic_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, traffic_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, traffic_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('4. Giao thong / Traffic Conditions', fontweight='bold')
    ax.set_xlabel('% (0=thoang, 100=tac)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 5. Loi nhuan
    ax = axes[2, 0]
    ax.plot(x, profit_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, profit_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, profit_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('5. Loi nhuan / Profit Per Delivery', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 6. DAU RA - So don ket hop
    ax = axes[2, 1]
    x3 = np.linspace(1, 10, 500)
    ax.plot(x3, combine_few(x3),  color=colors[0], lw=2, label='It/Few (1-4)')
    ax.plot(x3, combine_some(x3), color=colors[1], lw=2, label='Mot so/Some (3-7)')
    ax.plot(x3, combine_many(x3), color=colors[2], lw=2, label='Nhieu/Many (6-10)')
    ax.set_title('6. [DAU RA] So don ket hop / Orders to Combine', fontweight='bold', color='red')
    ax.set_xlabel('So don'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 7. DAU RA - Uu tien giao hang
    ax = axes[3, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, priority_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, priority_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, priority_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('7. [DAU RA] Uu tien giao hang / Delivery Priority', fontweight='bold', color='red')
    ax.set_xlabel('Muc uu tien (0-100)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # An o cuoi
    axes[3, 1].set_visible(False)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    # -- FIGURE 2: KET QUA GIAI MO --
    fig2, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

    tc0 = results[0]
    tc, comb_val, prio_val, m, r_out, c_agg, p_agg = tc0

    fig2.suptitle('KET QUA SUY LUAN MO - TINH HUONG GIAO TRINH',
                  fontsize=13, fontweight='bold')

    # So don ket hop
    ax1.fill_between(x_combine, c_agg, alpha=0.45, color='#FF5722')
    ax1.plot(x_combine, c_agg, color='#D84315', lw=1.5)
    ax1.axvline(x=comb_val, color='red', lw=2, ls='--',
                label=f'Centroid = {comb_val:.2f} don')
    ax1.set_title(f'So don ket hop: {comb_val:.2f}', fontweight='bold')
    ax1.set_xlabel('So don'); ax1.set_ylabel('mu(x)')
    ax1.legend(fontsize=9); ax1.grid(True, alpha=0.3)

    # Uu tien
    ax2.fill_between(x_priority, p_agg, alpha=0.45, color='#4CAF50')
    ax2.plot(x_priority, p_agg, color='#2E7D32', lw=1.5)
    ax2.axvline(x=prio_val, color='green', lw=2, ls='--',
                label=f'Centroid = {prio_val:.2f}')
    ax2.set_title(f'Uu tien giao hang: {prio_val:.2f}/100', fontweight='bold')
    ax2.set_xlabel('Muc uu tien'); ax2.set_ylabel('mu(x)')
    ax2.legend(fontsize=9); ax2.grid(True, alpha=0.3)

    dm, ur, ld, tr, pf = tc['inputs']
    info = f'MD={dm}%, KC={ur}, TT={ld}%, GT={tr}%, LN={pf}%'
    ax1.text(0.02, 0.95, info, transform=ax1.transAxes, fontsize=8,
             va='top', ha='left',
             bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.7))

    plt.tight_layout()

    print("\n  -> Do thi dang hien thi. Dong cua so de ket thuc.")
    plt.show()
