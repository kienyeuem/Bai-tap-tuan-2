"""
=============================================================================
BAI TAP TRI TUE NHAN TAO - HE THONG LOGIC MO
TINH HUONG 3: KE HOACH CHIEN LUOC BAN HANG CUA SHOPEE
             DANH CHO CAC CUA HANG (Mat hang dac biet)
=============================================================================
5 bien dau vao, 1 bien dau ra, 10 luat mo
Phuong phap: Mamdani Fuzzy Inference System
Giai mo: Phuong phap trong tam (Centroid Defuzzification)
=============================================================================
"""

import numpy as np

# =============================================================================
# PHAN 1: DINH NGHIA HAM THUOC (MEMBERSHIP FUNCTIONS)
# =============================================================================

def trimf(x, params):
    a, b, c = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x <= b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x > b) & (x < c)
    if c - b != 0: result[mask2] = (c - x[mask2]) / (c - b)
    result[x == b] = 1.0
    return result

def trapmf(x, params):
    a, b, c, d = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x < b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x >= b) & (x <= c)
    result[mask2] = 1.0
    mask3 = (x > c) & (x < d)
    if d - c != 0: result[mask3] = (d - x[mask3]) / (d - c)
    return result

# --- 1. Nhu cau san pham / Product Demand: 0 - 100% ---
x_demand = np.linspace(0, 100, 500)
def demand_low(x):    return trapmf(x, [0, 0, 10, 35])
def demand_medium(x): return trimf(x, [20, 50, 80])
def demand_high(x):   return trapmf(x, [65, 85, 100, 100])

# --- 2. Ap luc doi thu / Competitor Pricing Pressure: 0 - 100% ---
x_comp = np.linspace(0, 100, 500)
def comp_low(x):    return trapmf(x, [0, 0, 10, 35])
def comp_medium(x): return trimf(x, [20, 50, 80])
def comp_high(x):   return trapmf(x, [65, 85, 100, 100])

# --- 3. Uy tin cua hang / Store Reputation: 1.0 - 5.0 sao ---
x_reputation = np.linspace(1, 5, 500)
def rep_low(x):    return trapmf(x, [1.0, 1.0, 2.5, 4.0])
def rep_medium(x): return trimf(x, [3.5, 4.25, 4.6])
def rep_high(x):   return trapmf(x, [4.5, 4.7, 5.0, 5.0])

# --- 4. Bien loi nhuan / Profit Margin: 0 - 100% ---
x_profit = np.linspace(0, 100, 500)
def profit_low(x):    return trapmf(x, [0, 0, 10, 35])
def profit_medium(x): return trimf(x, [20, 50, 80])
def profit_high(x):   return trapmf(x, [65, 85, 100, 100])

# --- 5. Nhu cau theo mua / Seasonal Demand: 0 - 10 ---
x_season = np.linspace(0, 10, 500)
def season_none(x):   return trapmf(x, [0, 0, 1, 3])
def season_medium(x): return trimf(x, [2, 5, 8])
def season_high(x):   return trapmf(x, [7, 9, 10, 10])

# --- BIEN DAU RA: Muc giam gia / Discount Percentage: 0 - 70% ---
x_discount = np.linspace(0, 70, 500)
def disc_very_low(x):  return trapmf(x, [0, 0, 2, 7])
def disc_low(x):       return trimf(x, [5, 7.5, 12])
def disc_medium(x):    return trimf(x, [10, 15, 22])
def disc_high(x):      return trimf(x, [20, 30, 42])
def disc_very_high(x): return trapmf(x, [40, 50, 70, 70])


# =============================================================================
# PHAN 2: MO HOA (FUZZIFICATION)
# =============================================================================

def fuzzify(demand, comp, reputation, profit, season):
    d  = np.array([demand])
    c  = np.array([comp])
    r  = np.array([reputation])
    p  = np.array([profit])
    s  = np.array([season])
    return {
        'demand_low':    float(demand_low(d)[0]),
        'demand_medium': float(demand_medium(d)[0]),
        'demand_high':   float(demand_high(d)[0]),
        'comp_low':    float(comp_low(c)[0]),
        'comp_medium': float(comp_medium(c)[0]),
        'comp_high':   float(comp_high(c)[0]),
        'rep_low':    float(rep_low(r)[0]),
        'rep_medium': float(rep_medium(r)[0]),
        'rep_high':   float(rep_high(r)[0]),
        'profit_low':    float(profit_low(p)[0]),
        'profit_medium': float(profit_medium(p)[0]),
        'profit_high':   float(profit_high(p)[0]),
        'season_none':   float(season_none(s)[0]),
        'season_medium': float(season_medium(s)[0]),
        'season_high':   float(season_high(s)[0]),
    }


# =============================================================================
# PHAN 3: CO SO LUAT MO (10 LUAT)
# =============================================================================

def evaluate_rules(m):
    rules = []

    # Luat 1: Neu (Nhu cau SP cao) VA (Ap luc DT thap) VA (Loi nhuan thap)
    #         -> Giam gia rat thap
    r1 = min(m['demand_high'], m['comp_low'], m['profit_low'])
    rules.append((r1, 'very_low'))

    # Luat 2: Neu (Nhu cau SP thap) VA (Ap luc DT cao) VA (Loi nhuan cao)
    #         -> Chiet khau cao
    r2 = min(m['demand_low'], m['comp_high'], m['profit_high'])
    rules.append((r2, 'high'))

    # Luat 3: Neu (Uy tin Cao) VA (Loi nhuan TB) VA (Nhu cau mua Cao)
    #         -> Chiet khau TB
    r3 = min(m['rep_high'], m['profit_medium'], m['season_high'])
    rules.append((r3, 'medium'))

    # Luat 4: Neu (Ap luc DT cao) VA (Nhu cau mua Cao) VA (Loi nhuan cao)
    #         -> Chiet khau rat cao
    r4 = min(m['comp_high'], m['season_high'], m['profit_high'])
    rules.append((r4, 'very_high'))

    # Luat 5: Neu (Uy tin Thap) VA (Nhu cau SP TB) VA (Loi nhuan thap)
    #         -> Chiet khau TB
    r5 = min(m['rep_low'], m['demand_medium'], m['profit_low'])
    rules.append((r5, 'medium'))

    # Luat 6: Neu (Nhu cau SP cao) VA (Mua khong co) VA (Ap luc DT thap)
    #         -> Chiet khau rat thap
    r6 = min(m['demand_high'], m['season_none'], m['comp_low'])
    rules.append((r6, 'very_low'))

    # Luat 7: Neu (Loi nhuan cao) VA (Ap luc DT TB) VA (Nhu cau mua TB)
    #         -> Chiet khau TB
    r7 = min(m['profit_high'], m['comp_medium'], m['season_medium'])
    rules.append((r7, 'medium'))

    # Luat 8: Neu (Loi nhuan cao) VA (Nhu cau mua Cao) VA (Ap luc DT TB)
    #         -> Chiet khau TB (Luat khop voi vi du giao trinh)
    r8 = min(m['profit_high'], m['season_high'], m['comp_medium'])
    rules.append((r8, 'medium'))

    # Luat 9: Neu (Nhu cau SP cao) VA (Loi nhuan cao) VA (Mua Cao)
    #         -> Chiet khau Thap
    r9 = min(m['demand_high'], m['profit_high'], m['season_high'])
    rules.append((r9, 'low'))

    # Luat 10: Neu (Uy tin TB) VA (Ap luc DT TB) VA (Loi nhuan cao)
    #          -> Chiet khau Thap
    r10 = min(m['rep_medium'], m['comp_medium'], m['profit_high'])
    rules.append((r10, 'low'))

    return rules


# =============================================================================
# PHAN 4: TONG HOP VA GIAI MO (CENTROID)
# =============================================================================

def aggregate_and_defuzzify(rules):
    disc_mfs = {
        'very_low':  disc_very_low,
        'low':       disc_low,
        'medium':    disc_medium,
        'high':      disc_high,
        'very_high': disc_very_high,
    }
    disc_agg = np.zeros_like(x_discount)
    for strength, output_set in rules:
        if strength == 0:
            continue
        mf_values = disc_mfs[output_set](x_discount)
        clipped = np.minimum(mf_values, strength)
        disc_agg = np.maximum(disc_agg, clipped)

    if np.sum(disc_agg) > 0:
        result = np.sum(x_discount * disc_agg) / np.sum(disc_agg)
    else:
        result = 0
    return result, disc_agg


def shopee_banhang_fuzzy(demand, comp, reputation, profit, season):
    memberships = fuzzify(demand, comp, reputation, profit, season)
    rules = evaluate_rules(memberships)
    discount, disc_agg = aggregate_and_defuzzify(rules)
    return discount, memberships, rules, disc_agg


# =============================================================================
# PHAN 5: CHAY VA HIEN THI
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  HE THONG LOGIC MO - CHIEN LUOC BAN HANG SHOPEE")
    print("  (Mat hang dac biet: thu cong, suu tam, cao cap)")
    print("=" * 70)

    rule_names = [
        "L1: NhuCau_Cao ^ DT_Thap ^ LN_Thap      -> CK Rat thap",
        "L2: NhuCau_Thap ^ DT_Cao ^ LN_Cao        -> CK Cao",
        "L3: UyTin_Cao ^ LN_TB ^ Mua_Cao           -> CK Trung binh",
        "L4: DT_Cao ^ Mua_Cao ^ LN_Cao             -> CK Rat cao",
        "L5: UyTin_Thap ^ NhuCau_TB ^ LN_Thap     -> CK Trung binh",
        "L6: NhuCau_Cao ^ Mua_Khong ^ DT_Thap     -> CK Rat thap",
        "L7: LN_Cao ^ DT_TB ^ Mua_TB               -> CK Trung binh",
        "L8: LN_Cao ^ Mua_Cao ^ DT_TB              -> CK Trung binh",
        "L9: NhuCau_Cao ^ LN_Cao ^ Mua_Cao         -> CK Thap",
        "L10: UyTin_TB ^ DT_TB ^ LN_Cao            -> CK Thap",
    ]

    test_cases = [
        {
            'name': 'TINH HUONG GIAO TRINH: Dong ho xa xi thu cong (Shopee 11.11)',
            'inputs': (80, 50, 4.2, 80, 9),
            'note': 'SP: Dong ho xa xi thu cong | Mua: Shopee 11.11',
        },
    ]

    results = []

    for tc in test_cases:
        demand, comp, reputation, profit, season = tc['inputs']
        discount, memberships, rules, disc_agg = shopee_banhang_fuzzy(
            demand, comp, reputation, profit, season
        )
        results.append((tc, discount, memberships, rules, disc_agg))

        print(f"\n{'---' * 23}")
        print(f"  {tc['name']}")
        if tc['note']:
            print(f"  ({tc['note']})")
        print(f"{'---' * 23}")
        print(f"  DAU VAO:")
        print(f"    Nhu cau san pham:      {demand}%")
        print(f"    Ap luc doi thu:         {comp}%")
        print(f"    Uy tin cua hang:        {reputation} / 5.0 sao")
        print(f"    Bien loi nhuan:         {profit}%")
        print(f"    Nhu cau theo mua:       {season} / 10")

        print(f"\n  DO THUOC (Fuzzification):")
        print(f"    Nhu cau SP:  Thap={memberships['demand_low']:.3f}, "
              f"TB={memberships['demand_medium']:.3f}, "
              f"Cao={memberships['demand_high']:.3f}")
        print(f"    Ap luc DT:  Thap={memberships['comp_low']:.3f}, "
              f"TB={memberships['comp_medium']:.3f}, "
              f"Cao={memberships['comp_high']:.3f}")
        print(f"    Uy tin:     Thap={memberships['rep_low']:.3f}, "
              f"TB={memberships['rep_medium']:.3f}, "
              f"Cao={memberships['rep_high']:.3f}")
        print(f"    Loi nhuan:  Thap={memberships['profit_low']:.3f}, "
              f"TB={memberships['profit_medium']:.3f}, "
              f"Cao={memberships['profit_high']:.3f}")
        print(f"    Mua:        Khong={memberships['season_none']:.3f}, "
              f"TB={memberships['season_medium']:.3f}, "
              f"Cao={memberships['season_high']:.3f}")

        print(f"\n  LUAT DUOC KICH HOAT:")
        activated = False
        for i, (strength, _) in enumerate(rules):
            if strength > 0:
                print(f"    {rule_names[i]}  =>  alpha = {strength:.3f}")
                activated = True
        if not activated:
            print(f"    (Khong co luat nao duoc kich hoat)")

        if discount < 5:
            label = "RAT THAP (0-5%)"
        elif discount < 10:
            label = "THAP (5-10%)"
        elif discount < 20:
            label = "TRUNG BINH (10-20%)"
        elif discount < 40:
            label = "CAO (20-40%)"
        else:
            label = "RAT CAO (40-70%)"

        print(f"\n  * KET QUA GIAI MO (Centroid):")
        print(f"    -> Muc giam gia:        {discount:.2f}%")
        print(f"    -> Phan loai:            {label}")

    print(f"\n{'=' * 70}")
    print("  HOAN TAT - Dang ve do thi...")
    print(f"{'=' * 70}")

    # =================================================================
    # PHAN 6: VE DO THI
    # =================================================================
    import matplotlib.pyplot as plt

    colors = ['#2196F3', '#4CAF50', '#FF9800', '#F44336', '#9C27B0']

    # -- FIGURE 1: HAM LIEN THUOC --
    fig1, axes = plt.subplots(3, 2, figsize=(14, 14))
    fig1.suptitle('DO THI HAM LIEN THUOC - CHIEN LUOC BAN HANG SHOPEE',
                  fontsize=14, fontweight='bold', y=0.98)

    # 1. Nhu cau san pham
    ax = axes[0, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, demand_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, demand_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, demand_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('1. Nhu cau san pham / Product Demand (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 2. Ap luc doi thu
    ax = axes[0, 1]
    ax.plot(x, comp_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, comp_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, comp_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('2. Ap luc doi thu / Competitor Pressure (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 3. Uy tin cua hang
    ax = axes[1, 0]
    x2 = np.linspace(1, 5, 500)
    ax.plot(x2, rep_low(x2),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x2, rep_medium(x2), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x2, rep_high(x2),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('3. Uy tin cua hang / Store Reputation (sao)', fontweight='bold')
    ax.set_xlabel('Sao (1-5)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 4. Bien loi nhuan
    ax = axes[1, 1]
    x = np.linspace(0, 100, 500)
    ax.plot(x, profit_low(x),    color=colors[0], lw=2, label='Thap/Low')
    ax.plot(x, profit_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, profit_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('4. Bien loi nhuan / Profit Margin (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 5. Nhu cau theo mua
    ax = axes[2, 0]
    x3 = np.linspace(0, 10, 500)
    ax.plot(x3, season_none(x3),   color=colors[0], lw=2, label='Khong co/None')
    ax.plot(x3, season_medium(x3), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x3, season_high(x3),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('5. Nhu cau theo mua / Seasonal Demand', fontweight='bold')
    ax.set_xlabel('Muc (0-10)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 6. DAU RA - Muc giam gia
    ax = axes[2, 1]
    x4 = np.linspace(0, 70, 500)
    ax.plot(x4, disc_very_low(x4),  color=colors[0], lw=2, label='Rat thap (0-5%)')
    ax.plot(x4, disc_low(x4),       color=colors[1], lw=2, label='Thap (5-10%)')
    ax.plot(x4, disc_medium(x4),    color=colors[2], lw=2, label='TB (10-20%)')
    ax.plot(x4, disc_high(x4),      color=colors[3], lw=2, label='Cao (20-40%)')
    ax.plot(x4, disc_very_high(x4), color=colors[4], lw=2, label='Rat cao (40-70%)')
    ax.set_title('6. [DAU RA] Muc giam gia / Discount (%)', fontweight='bold', color='red')
    ax.set_xlabel('Giam gia (%)'); ax.set_ylabel('mu(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    # -- FIGURE 2: KET QUA GIAI MO --
    n = len(results)
    cols = 3
    rows_fig = (n + cols - 1) // cols
    fig2, axes2 = plt.subplots(rows_fig, cols, figsize=(15, 4 * rows_fig))
    fig2.suptitle('KET QUA GIAI MO TRONG TAM (CENTROID) - TUNG TINH HUONG',
                  fontsize=13, fontweight='bold', y=0.99)

    axes2_flat = axes2.flatten()
    for idx, (tc, disc, m, rules_out, d_agg) in enumerate(results):
        ax = axes2_flat[idx]
        ax.fill_between(x_discount, d_agg, alpha=0.45, color='#FF5722')
        ax.plot(x_discount, d_agg, color='#D84315', lw=1.5)
        ax.axvline(x=disc, color='red', lw=2, ls='--', label=f'Centroid = {disc:.2f}%')
        ax.set_title(f'TH{idx+1}: CK = {disc:.2f}%', fontweight='bold', fontsize=10)
        ax.set_xlabel('Giam gia (%)'); ax.set_ylabel('mu(x)')
        ax.legend(fontsize=8); ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 70)

        dm, cp, rp, pf, ss = tc['inputs']
        info = f'NC={dm}%, DT={cp}%, UT={rp}, LN={pf}%, Mua={ss}'
        ax.text(0.02, 0.95, info, transform=ax.transAxes, fontsize=7,
                va='top', ha='left',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.7))

    for idx in range(len(results), len(axes2_flat)):
        axes2_flat[idx].set_visible(False)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    print("\n  -> Do thi dang hien thi. Dong cua so de ket thuc.")
    plt.show()
