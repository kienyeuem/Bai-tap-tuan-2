"""
=============================================================================
BÀI TẬP TRÍ TUỆ NHÂN TẠO - HỆ THỐNG LOGIC MỜ
TÌNH HUỐNG 2: CHIẾN LƯỢC CHIẾT KHẤU CHO CỬA HÀNG SHOPEE
=============================================================================
5 biến đầu vào, 1 biến đầu ra, 7 luật mờ
Phương pháp: Mamdani Fuzzy Inference System
Giải mờ: Phương pháp trọng tâm (Centroid Defuzzification)
=============================================================================
"""

import numpy as np

# =============================================================================
# PHẦN 1: ĐỊNH NGHĨA HÀM THUỘC (MEMBERSHIP FUNCTIONS)
# =============================================================================

def trimf(x, params):
    """Hàm thuộc tam giác"""
    a, b, c = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x <= b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x > b) & (x < c)
    if c - b != 0: result[mask2] = (c - x[mask2]) / (c - b)
    result[x == b] = 1.0
    return result

def trapmf(x, params):
    """Hàm thuộc hình thang"""
    a, b, c, d = params
    result = np.zeros_like(x, dtype=float)
    mask1 = (x > a) & (x < b)
    if b - a != 0: result[mask1] = (x[mask1] - a) / (b - a)
    mask2 = (x >= b) & (x <= c)
    result[mask2] = 1.0
    mask3 = (x > c) & (x < d)
    if d - c != 0: result[mask3] = (d - x[mask3]) / (d - c)
    return result

# --- 1. Đánh giá cửa hàng / Store Rating: 1.0 - 5.0 ---
x_rating = np.linspace(1, 5, 500)
def store_low(x):    return trapmf(x, [1.0, 1.0, 2.5, 4.0])
def store_medium(x): return trimf(x, [3.5, 4.25, 4.6])
def store_high(x):   return trapmf(x, [4.5, 4.7, 5.0, 5.0])

# --- 2. Khối lượng bán hàng / Sales Volume: 0 - 100 (%) ---
x_sales = np.linspace(0, 100, 500)
def sales_low(x):    return trapmf(x, [0, 0, 10, 40])
def sales_medium(x): return trimf(x, [20, 50, 80])
def sales_high(x):   return trapmf(x, [60, 80, 100, 100])

# --- 3. Biên lợi nhuận / Profit Margin: 0 - 100 (%) ---
x_profit = np.linspace(0, 100, 500)
def profit_low(x):    return trapmf(x, [0, 0, 10, 35])
def profit_medium(x): return trimf(x, [20, 45, 70])
def profit_high(x):   return trapmf(x, [55, 75, 100, 100])

# --- 4. Sự kiện theo mùa / Seasonal Event: 0 - 10 ---
x_event = np.linspace(0, 10, 500)
def event_none(x):     return trapmf(x, [0, 0, 1, 3])
def event_moderate(x): return trimf(x, [2, 5, 8])
def event_high(x):     return trapmf(x, [7, 9, 10, 10])

# --- 5. Giảm giá đối thủ / Competitor Discounts: 0 - 100 (%) ---
x_competitor = np.linspace(0, 100, 500)
def comp_low(x):    return trapmf(x, [0, 0, 10, 35])
def comp_medium(x): return trimf(x, [20, 45, 70])
def comp_high(x):   return trapmf(x, [55, 75, 100, 100])

# --- BIẾN ĐẦU RA: Tỷ lệ chiết khấu (%) : 0 - 70 ---
x_discount = np.linspace(0, 70, 500)
def disc_very_low(x):  return trapmf(x, [0, 0, 2, 7])
def disc_low(x):       return trimf(x, [5, 7.5, 12])
def disc_medium(x):    return trimf(x, [10, 15, 22])
def disc_high(x):      return trimf(x, [20, 30, 42])
def disc_very_high(x): return trapmf(x, [40, 50, 70, 70])


# =============================================================================
# PHẦN 2: MỜ HÓA (FUZZIFICATION)
# =============================================================================

def fuzzify(rating, sales, profit, event, competitor):
    r = np.array([rating])
    s = np.array([sales])
    p = np.array([profit])
    e = np.array([event])
    c = np.array([competitor])
    return {
        'store_low':    float(store_low(r)[0]),
        'store_medium': float(store_medium(r)[0]),
        'store_high':   float(store_high(r)[0]),
        'sales_low':    float(sales_low(s)[0]),
        'sales_medium': float(sales_medium(s)[0]),
        'sales_high':   float(sales_high(s)[0]),
        'profit_low':   float(profit_low(p)[0]),
        'profit_medium':float(profit_medium(p)[0]),
        'profit_high':  float(profit_high(p)[0]),
        'event_none':     float(event_none(e)[0]),
        'event_moderate': float(event_moderate(e)[0]),
        'event_high':     float(event_high(e)[0]),
        'comp_low':    float(comp_low(c)[0]),
        'comp_medium': float(comp_medium(c)[0]),
        'comp_high':   float(comp_high(c)[0]),
    }


# =============================================================================
# PHẦN 3: CƠ SỞ LUẬT MỜ (7 LUẬT)
# =============================================================================

def evaluate_rules(m):
    rules = []

    # Luật 1: Nếu (Xếp hạng Cao) VÀ (KL bán hàng Cao) VÀ (Lợi nhuận Cao) → Chiết khấu Rất thấp
    r1 = min(m['store_high'], m['sales_high'], m['profit_high'])
    rules.append((r1, 'very_low'))

    # Luật 2: Nếu (Xếp hạng Thấp) VÀ (KL bán hàng Thấp) VÀ (Lợi nhuận Cao) → Chiết khấu Cao
    r2 = min(m['store_low'], m['sales_low'], m['profit_high'])
    rules.append((r2, 'high'))

    # Luật 3: Nếu (Sự kiện Cao) VÀ (Đối thủ Cao) → Chiết khấu Rất cao
    r3 = min(m['event_high'], m['comp_high'])
    rules.append((r3, 'very_high'))

    # Luật 4: Nếu (Xếp hạng TB) VÀ (KL bán hàng TB) VÀ (Lợi nhuận TB) → Chiết khấu TB
    r4 = min(m['store_medium'], m['sales_medium'], m['profit_medium'])
    rules.append((r4, 'medium'))

    # Luật 5: Nếu (Đối thủ Thấp) VÀ (Lợi nhuận Thấp) VÀ (KL bán hàng Cao) → Chiết khấu Rất thấp
    r5 = min(m['comp_low'], m['profit_low'], m['sales_high'])
    rules.append((r5, 'very_low'))

    # Luật 6: Nếu (Xếp hạng Thấp) VÀ (Sự kiện Không có) → Chiết khấu TB
    r6 = min(m['store_low'], m['event_none'])
    rules.append((r6, 'medium'))

    # Luật 7: Nếu (KL bán hàng Thấp) VÀ (Lợi nhuận Thấp) → Chiết khấu Rất cao
    r7 = min(m['sales_low'], m['profit_low'])
    rules.append((r7, 'very_high'))

    return rules


# =============================================================================
# PHẦN 4: TỔNG HỢP VÀ GIẢI MỜ (CENTROID)
# =============================================================================

def aggregate_and_defuzzify(rules):
    disc_mfs = {
        'very_low':  disc_very_low,
        'low':       disc_low,
        'medium':    disc_medium,
        'high':      disc_high,
        'very_high': disc_very_high,
    }

    disc_agg = np.zeros_like(x_discount)

    for strength, output_set in rules:
        if strength == 0:
            continue
        mf_values = disc_mfs[output_set](x_discount)
        clipped = np.minimum(mf_values, strength)
        disc_agg = np.maximum(disc_agg, clipped)

    if np.sum(disc_agg) > 0:
        result = np.sum(x_discount * disc_agg) / np.sum(disc_agg)
    else:
        result = 0

    return result, disc_agg


# =============================================================================
# PHẦN 5: HÀM CHÍNH
# =============================================================================

def shopee_fuzzy_system(rating, sales, profit, event, competitor):
    memberships = fuzzify(rating, sales, profit, event, competitor)
    rules = evaluate_rules(memberships)
    discount, disc_agg = aggregate_and_defuzzify(rules)
    return discount, memberships, rules, disc_agg


# =============================================================================
# PHẦN 6: CHẠY VÀ HIỂN THỊ
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("  HỆ THỐNG LOGIC MỜ SHOPEE - CHIẾN LƯỢC CHIẾT KHẤU")
    print("=" * 70)

    test_cases = [
        {
            'name': 'TH1: Cửa hàng tốt, bán nhiều, lợi nhuận cao (không cần giảm)',
            'inputs': (4.8, 85, 80, 2, 20),
        },
        {
            'name': 'TH2: Cửa hàng kém, bán ít, lợi nhuận cao (cần thu hút KH)',
            'inputs': (2.5, 15, 75, 1, 30),
        },
        {
            'name': 'TH3: Sự kiện lớn + đối thủ giảm mạnh (cạnh tranh tối đa)',
            'inputs': (4.3, 50, 45, 9, 80),
        },
        {
            'name': 'TH4: Mọi thứ trung bình (Ví dụ trong giáo trình)',
            'inputs': (4.3, 50, 20, 9, 80),
        },
        {
            'name': 'TH5: Đối thủ ít giảm, lợi nhuận thấp, bán nhiều',
            'inputs': (4.0, 80, 15, 3, 10),
        },
        {
            'name': 'TH6: Cửa hàng kém, không có sự kiện',
            'inputs': (2.0, 30, 40, 1, 25),
        },
        {
            'name': 'TH7: Bán ít, lợi nhuận thấp (cần khuyến khích bán)',
            'inputs': (3.5, 10, 10, 4, 40),
        },
    ]

    rule_names = [
        "L1: XH_Cao ∧ KL_Cao ∧ LN_Cao       → CK Rất thấp",
        "L2: XH_Thấp ∧ KL_Thấp ∧ LN_Cao     → CK Cao",
        "L3: SK_Cao ∧ ĐT_Cao                  → CK Rất cao",
        "L4: XH_TB ∧ KL_TB ∧ LN_TB            → CK Trung bình",
        "L5: ĐT_Thấp ∧ LN_Thấp ∧ KL_Cao     → CK Rất thấp",
        "L6: XH_Thấp ∧ SK_Không có            → CK Trung bình",
        "L7: KL_Thấp ∧ LN_Thấp                → CK Rất cao",
    ]

    results = []

    for tc in test_cases:
        rating, sales, profit, event, competitor = tc['inputs']
        discount, memberships, rules, disc_agg = shopee_fuzzy_system(
            rating, sales, profit, event, competitor
        )
        results.append((tc, discount, memberships, rules, disc_agg))

        print(f"\n{'─' * 70}")
        print(f"  {tc['name']}")
        print(f"{'─' * 70}")
        print(f"  ĐẦU VÀO:")
        print(f"    Xếp hạng cửa hàng:     {rating} / 5.0 sao")
        print(f"    Khối lượng bán hàng:    {sales}%")
        print(f"    Biên lợi nhuận:         {profit}%")
        print(f"    Sự kiện theo mùa:       {event} / 10")
        print(f"    Giảm giá đối thủ:       {competitor}%")

        print(f"\n  ĐỘ THUỘC (Fuzzification):")
        print(f"    Xếp hạng:   Thấp={memberships['store_low']:.3f}, "
              f"TB={memberships['store_medium']:.3f}, "
              f"Cao={memberships['store_high']:.3f}")
        print(f"    KL bán:     Thấp={memberships['sales_low']:.3f}, "
              f"TB={memberships['sales_medium']:.3f}, "
              f"Cao={memberships['sales_high']:.3f}")
        print(f"    Lợi nhuận:  Thấp={memberships['profit_low']:.3f}, "
              f"TB={memberships['profit_medium']:.3f}, "
              f"Cao={memberships['profit_high']:.3f}")
        print(f"    Sự kiện:    Không={memberships['event_none']:.3f}, "
              f"TB={memberships['event_moderate']:.3f}, "
              f"Cao={memberships['event_high']:.3f}")
        print(f"    Đối thủ:    Thấp={memberships['comp_low']:.3f}, "
              f"TB={memberships['comp_medium']:.3f}, "
              f"Cao={memberships['comp_high']:.3f}")

        print(f"\n  LUẬT ĐƯỢC KÍCH HOẠT:")
        for i, (strength, _) in enumerate(rules):
            if strength > 0:
                print(f"    {rule_names[i]}  =>  α = {strength:.3f}")

        # Phân loại
        if discount < 5:
            label = "RẤT THẤP (0-5%)"
        elif discount < 10:
            label = "THẤP (5-10%)"
        elif discount < 20:
            label = "TRUNG BÌNH (10-20%)"
        elif discount < 40:
            label = "CAO (20-40%)"
        else:
            label = "RẤT CAO (40-70%)"

        print(f"\n  ★ KẾT QUẢ GIẢI MỜ (Centroid):")
        print(f"    → Chiết khấu:          {discount:.2f}%")
        print(f"    → Mức (ngôn ngữ):      {label}")

    print(f"\n{'=' * 70}")
    print("  HOÀN TẤT - Đang vẽ đồ thị...")
    print(f"{'=' * 70}")

    # =================================================================
    # PHẦN 7: VẼ ĐỒ THỊ
    # =================================================================
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.rcParams['font.size'] = 10

    colors = ['#2196F3', '#4CAF50', '#FF9800', '#F44336', '#9C27B0']

    # ── FIGURE 1: HÀM LIÊN THUỘC ──
    fig1, axes = plt.subplots(3, 2, figsize=(14, 14))
    fig1.suptitle('ĐỒ THỊ HÀM LIÊN THUỘC - CHIẾT KHẤU CỬA HÀNG SHOPEE',
                  fontsize=14, fontweight='bold', y=0.98)

    # 1. Xếp hạng cửa hàng
    ax = axes[0, 0]
    x = np.linspace(1, 5, 500)
    ax.plot(x, store_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, store_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, store_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('1. Xếp hạng cửa hàng / Store Rating (sao)', fontweight='bold')
    ax.set_xlabel('Sao (1.0 - 5.0)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 2. Khối lượng bán hàng
    ax = axes[0, 1]
    x = np.linspace(0, 100, 500)
    ax.plot(x, sales_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, sales_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, sales_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('2. Khối lượng bán hàng / Sales Volume (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 3. Biên lợi nhuận
    ax = axes[1, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, profit_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, profit_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, profit_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('3. Biên lợi nhuận / Profit Margin (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 4. Sự kiện theo mùa
    ax = axes[1, 1]
    x = np.linspace(0, 10, 500)
    ax.plot(x, event_none(x),     color=colors[0], lw=2, label='Không có/None')
    ax.plot(x, event_moderate(x), color=colors[1], lw=2, label='TB/Moderate')
    ax.plot(x, event_high(x),     color=colors[2], lw=2, label='Cao/High')
    ax.set_title('4. Sự kiện theo mùa / Seasonal Event', fontweight='bold')
    ax.set_xlabel('Mức độ (0-10)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 5. Giảm giá đối thủ
    ax = axes[2, 0]
    x = np.linspace(0, 100, 500)
    ax.plot(x, comp_low(x),    color=colors[0], lw=2, label='Thấp/Low')
    ax.plot(x, comp_medium(x), color=colors[1], lw=2, label='TB/Medium')
    ax.plot(x, comp_high(x),   color=colors[2], lw=2, label='Cao/High')
    ax.set_title('5. Giảm giá đối thủ / Competitor Discounts (%)', fontweight='bold')
    ax.set_xlabel('%'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=9); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    # 6. BIẾN ĐẦU RA - Chiết khấu
    ax = axes[2, 1]
    x = np.linspace(0, 70, 500)
    ax.plot(x, disc_very_low(x),  color=colors[0], lw=2, label='Rất thấp (0-5%)')
    ax.plot(x, disc_low(x),       color=colors[1], lw=2, label='Thấp (5-10%)')
    ax.plot(x, disc_medium(x),    color=colors[2], lw=2, label='TB (10-20%)')
    ax.plot(x, disc_high(x),      color=colors[3], lw=2, label='Cao (20-40%)')
    ax.plot(x, disc_very_high(x), color=colors[4], lw=2, label='Rất cao (40-70%)')
    ax.set_title('6. [ĐẦU RA] Chiết khấu / Discount (%)', fontweight='bold', color='red')
    ax.set_xlabel('Chiết khấu (%)'); ax.set_ylabel('μ(x)')
    ax.legend(fontsize=8); ax.set_ylim(-0.05, 1.15); ax.grid(True, alpha=0.3)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    # ── FIGURE 2: KẾT QUẢ SUY LUẬN CHO TỪNG TÌNH HUỐNG ──
    n = len(results)
    cols = 3
    rows = (n + cols - 1) // cols
    fig2, axes2 = plt.subplots(rows, cols, figsize=(15, 4 * rows))
    fig2.suptitle('KẾT QUẢ GIẢI MỜ TRỌNG TÂM (CENTROID) - TỪNG TÌNH HUỐNG',
                  fontsize=13, fontweight='bold', y=0.99)

    axes2_flat = axes2.flatten()
    for idx, (tc, disc, m, rules_out, d_agg) in enumerate(results):
        ax = axes2_flat[idx]
        ax.fill_between(x_discount, d_agg, alpha=0.45, color='#FF5722')
        ax.plot(x_discount, d_agg, color='#D84315', lw=1.5)
        ax.axvline(x=disc, color='red', lw=2, ls='--', label=f'Centroid = {disc:.2f}%')
        ax.set_title(f'TH{idx+1}: CK = {disc:.2f}%', fontweight='bold', fontsize=10)
        ax.set_xlabel('Chiết khấu (%)'); ax.set_ylabel('μ(x)')
        ax.legend(fontsize=8); ax.grid(True, alpha=0.3)
        ax.set_xlim(0, 70)

        r, s, p, e, c = tc['inputs']
        info = f'XH={r}, KL={s}%, LN={p}%, SK={e}, ĐT={c}%'
        ax.text(0.02, 0.95, info, transform=ax.transAxes, fontsize=7,
                va='top', ha='left',
                bbox=dict(boxstyle='round,pad=0.3', facecolor='wheat', alpha=0.7))

    # Ẩn ô trống nếu có
    for idx in range(len(results), len(axes2_flat)):
        axes2_flat[idx].set_visible(False)

    plt.tight_layout(rect=[0, 0, 1, 0.96])

    print("\n  → Đồ thị đang hiển thị. Đóng cửa sổ để kết thúc.")
    plt.show()
